 ----------------------------------------------
| Gabriel's Blue skin for Ultima Online - v1.0 |
|   specially designed for Neverlands Shard    |
|  gabrielf1@uol.com.br - www.neverlands.org   |
 ----------------------------------------------


Hello everyone.

This .mul file contains my blue skin for Ultima Online.
It was designed from bitmap files Developer Devious once
made available for users of Neverlands to create their
owns skins. And so I did.

Most of the windows in UO (editable ones) are now blue.
I also took the liberty to change the background of the
original Neverlands' verdata file. Personally, I like
mine better, altho the girls in the dragons weren't any
bad ;)

Also it's worth to remember this verdata.mul file
contains every latest file released by staff as official
Neverlands' file. Therefore, you don't need to worry not
seeing colours, houses, etc.

Please, report me any bugs you may ever find.


Have fun!!!


Gabriel, Speed Knight of the Round
Neverlands' official vrooomer ;)
=========================================================
F1 rules you all! Ayrton Senna forever! =)
=========================================================

Special Thanks
--------------

My biggest thanks goes, of course, to Developer Devious,
who helped me finding bugs, and compiled all the bmps
into the mul file. Without him, this would never be done.

Of course, thanks to Andra for giving his real money for
a great shard. If it weren't for him, we'd never be here.

Also thanks for the guys that helped me taking the screen-
shots.