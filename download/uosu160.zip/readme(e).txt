*Ultima Online Screenshot Utility - Document

** before using

ZIP file contains these files.
uosu.exe	executable file (need to run)
nviolib.dll     jpge dll (need to run)
readme(j).txt	document file (Japanese)
readme(e).txt	document file (English)

** Run
Execute "uosu.exe".

** Further explanation
See support page.
http://mwc.ne.jp/katuyuki/UOSoft/

** Copyrights and others.
This is a freeware.
Copyright (c) 1998 Katsuyuki Namba (katuyuki@kk.iij4u.or.jp)
I am not responsible for all troubles which may be caused by this software.
You can't upload this software, but you can introduce and set a link to support page.


**Hystory
1.30 - fix the problem causing UO client crush
1.32B - Add an option of JPEG compression / not.
1.33 - fix the font problem on some WIndows 95(Germany)
1.50 - use ini file in local folder rather than registry.
1.60 - add 800x600 clipping.